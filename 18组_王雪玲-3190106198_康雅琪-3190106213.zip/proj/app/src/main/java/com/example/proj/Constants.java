package com.example.proj;

import okhttp3.MultipartBody;

public class Constants {
    public static final String BASE_URL = "https://api-android-camp.bytedance.com/zju/invoke/";
    public static final String token = "WkpVLWJ5dGVkYW5jZS1hbmRyb2lk";
    public static final String STUDENT_ID = "6213+6198";
    public static final String USER_NAME = "Bourbon";
}
